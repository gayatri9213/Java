package com.csvtojson.sevice;

import com.csvtojson.util.UnsupportedFileTypeException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import io.micrometer.core.instrument.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.net.URI;
import java.util.*;

@Service
public class CsvToJsonServiceImpl implements CsvToJsonService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CsvToJsonServiceImpl.class);
    private static final String MESSAGE = "message";
    private static final String FILE_CONVERTED = "fileConverted";
    private static final String JSON_RESPONSE = "jsonResponse";

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    public ResponseEntity<Object> convertCsvToJsonFileFromUrl(String url, char delimiter, String jsonFileLocation) throws IOException, UnsupportedFileTypeException {
        LOGGER.info(env.getProperty("csvToJsonUrl"));
        validateFile(url);
        CsvMapper csvMapper = new CsvMapper();
        ObjectMapper objectMapper = new ObjectMapper();
        String csvString = restTemplate.getForObject(url, String.class);
        CsvSchema schema = CsvSchema.emptySchema().withHeader().withColumnSeparator(delimiter);
        List<Object> csvData = csvMapper.readerFor(Map.class).with(schema).readValues(csvString).readAll();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        String jsonData = objectMapper.writeValueAsString(csvData);
        if (StringUtils.isNotBlank(jsonFileLocation)) {
            URI uri = URI.create(url);
            String csvFileName = uri.getPath().substring(uri.getPath().lastIndexOf('/') + 1);
            File jsonFileNameWithLocation = createFile(csvFileName, jsonData, jsonFileLocation);
            Map<String, String> responseBody = new HashMap<>();
            responseBody.put(MESSAGE, env.getProperty(FILE_CONVERTED) + jsonFileNameWithLocation);
            LOGGER.info("{} {}", env.getProperty(FILE_CONVERTED), jsonFileNameWithLocation);
            return new ResponseEntity<>(responseBody, HttpStatus.CREATED);
        } else {
            LOGGER.info(env.getProperty(JSON_RESPONSE));
            return new ResponseEntity<>(jsonData, HttpStatus.OK);
        }
    }

    public ResponseEntity<Object> convertCsvToJsonFileFromSystem(MultipartFile file, char delimiter, String jsonFileLocation) throws IOException, UnsupportedFileTypeException {
        LOGGER.info(env.getProperty("csvToJsonFile"));
        String csvFileName = file.getOriginalFilename();
        validateFile(csvFileName);
        CsvMapper csvMapper = new CsvMapper();
        ObjectMapper objectMapper = new ObjectMapper();
        CsvSchema schema = CsvSchema.emptySchema().withHeader().withColumnSeparator(delimiter);
        List<Object> csvData = csvMapper.readerFor(Map.class).with(schema).readValues(file.getInputStream()).readAll();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        String jsonData = objectMapper.writeValueAsString(csvData);
        if (StringUtils.isNotBlank(jsonFileLocation)) {
            File jsonFileNameWithLocation = createFile(csvFileName, jsonData, jsonFileLocation);
            Map<String, String> responseBody = new HashMap<>();
            responseBody.put(MESSAGE, env.getProperty(FILE_CONVERTED) + jsonFileNameWithLocation);
            LOGGER.info("{} {}", env.getProperty(FILE_CONVERTED), jsonFileNameWithLocation);
            return new ResponseEntity<>(responseBody, HttpStatus.CREATED);
        } else {
            LOGGER.info(env.getProperty(JSON_RESPONSE));
            return new ResponseEntity<>(jsonData, HttpStatus.OK);
        }
    }

    public ResponseEntity<Object> convertCsvToJsonFileFromSharePoint(String fileName, char delimiter) throws IOException, UnsupportedFileTypeException {
        LOGGER.info(env.getProperty("csvToJsonSharePointUsingFile"));
        validateFile(fileName);
        CsvMapper csvMapper = new CsvMapper();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        CsvSchema schema = CsvSchema.emptySchema().withHeader().withColumnSeparator(delimiter);
        headers.set("Authorization", "Bearer " + generateToken());
        headers.add("Accept", "application/json;odata=verbose");
        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        String apiUrl = env.getProperty("sharePoint.site.url") + "/_api/web/lists/getbytitle('5GNDataRepo')/rootfolder/files/getbyurl(url='" + fileName + "')/$value?binaryStringResponseBody=true";
        String csvFileData = restTemplate.exchange(apiUrl, HttpMethod.GET, entity, String.class).getBody();
        if (csvFileData.startsWith("ï»¿\"")) {
            csvFileData = csvFileData.substring(3);
        }
        List<Object> csvData = csvMapper.readerFor(Map.class).with(schema).readValues(csvFileData).readAll();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        String jsonData = objectMapper.writeValueAsString(csvData);
        LOGGER.info(env.getProperty(JSON_RESPONSE));
        return new ResponseEntity<>(jsonData, HttpStatus.OK);
    }

    public ResponseEntity<Object> convertCsvToJsonFromSharePointUsingLocation(String fileUrl, char delimiter) throws IOException, UnsupportedFileTypeException {
        LOGGER.info(env.getProperty("csvToJsonSharePointUsingFileLocation"));
        validateFile(fileUrl);
        CsvMapper csvMapper = new CsvMapper();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        CsvSchema schema = CsvSchema.emptySchema().withHeader().withColumnSeparator(delimiter);
        headers.set("Authorization", "Bearer " + generateToken());
        headers.add("Accept", "application/json;odata=verbose");
        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        String sharePointUrl = env.getProperty("sharePoint.site.url") + "/_api/Web/GetFileByServerRelativePath(decodedurl='/" + fileUrl + "')/$value";
        String csvFileData = restTemplate.exchange(sharePointUrl, HttpMethod.GET, entity, String.class).getBody();
        if (csvFileData.startsWith("ï»¿\"")) {
            csvFileData = csvFileData.substring(3);
        }
        List<Object> csvData = csvMapper.readerFor(Map.class).with(schema).readValues(csvFileData).readAll();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        String jsonData = objectMapper.writeValueAsString(csvData);
        LOGGER.info(env.getProperty(JSON_RESPONSE));
        return new ResponseEntity<>(jsonData, HttpStatus.OK);
    }

    private void validateFile(String fileName) throws FileNotFoundException, UnsupportedFileTypeException {
        if (fileName.isEmpty())
            throw new FileNotFoundException("The file you are trying to convert does not exist. Please check the file and try again.");
        if (!fileName.endsWith(".csv"))
            throw new UnsupportedFileTypeException("Unsupported media type detected. Please select a .csv file.");
    }

    private File createFile(String csvFileName, String jsonData, String jsonFileLocation) throws IOException {
        File jsonFileNameWithLocation;
        jsonFileNameWithLocation = new File(jsonFileLocation);
        if (jsonFileNameWithLocation.isDirectory()) {
            LOGGER.info("{}{}", env.getProperty("csvFile"), csvFileName);
            String jsonFilename = csvFileName.replace(".csv", ".json");
            LOGGER.info("{}{}", env.getProperty("jsonFile"), jsonFilename);
            jsonFileNameWithLocation = new File(jsonFileLocation, jsonFilename);
        } else {
            throw new FileNotFoundException(jsonFileLocation + " does not exits");
        }
        try (FileWriter writer = new FileWriter(jsonFileNameWithLocation)) {
            writer.write(jsonData);
        }
        return jsonFileNameWithLocation;
    }

    private String generateToken() throws JsonProcessingException {
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();

        formData.add("grant_type", env.getProperty("sharePoint.grantType"));
        formData.add("client_id", env.getProperty("sharePoint.client.id"));
        formData.add("client_secret", env.getProperty("sharePoint.client.secret"));
        formData.add("resource", env.getProperty("sharePoint.resource"));
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
        String accessToken = restTemplate.postForObject(env.getProperty("sharePoint.oauth.endpoint"), request, String.class);
        Object json = objectMapper.readValue(accessToken, Object.class);
        String formattedAccessToken = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
        JsonNode jsonNode = objectMapper.readTree(formattedAccessToken);
        formattedAccessToken = jsonNode.get("access_token").asText();
        return formattedAccessToken;
    }
}
