package com.csvtojson.controller.advice;

import com.csvtojson.util.ErrorResponse;
import com.csvtojson.util.UnsupportedFileTypeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.io.FileNotFoundException;

@ControllerAdvice
public class CsvToJsonControllerAdvice {

    private static final Logger LOGGER = LoggerFactory.getLogger(CsvToJsonControllerAdvice.class);
    private static final String STATUS = "FAILED";

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    @ResponseStatus(value = HttpStatus.PAYLOAD_TOO_LARGE)
    public ResponseEntity<ErrorResponse> handleMultipartException(MaxUploadSizeExceededException e) {
        ErrorResponse error = new ErrorResponse(STATUS, e.getRootCause().getLocalizedMessage());
        LOGGER.error("MaxUploadSizeExceededException : {}", e.getRootCause().getLocalizedMessage());
        return new ResponseEntity<>(error, HttpStatus.PAYLOAD_TOO_LARGE);
    }

    @ExceptionHandler(FileNotFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorResponse> fileNotFoundException(FileNotFoundException exception) {
        ErrorResponse error = new ErrorResponse(STATUS, exception.getMessage());
        LOGGER.error(exception.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(UnsupportedFileTypeException.class)
    @ResponseStatus(value = HttpStatus.UNSUPPORTED_MEDIA_TYPE)
    public ResponseEntity<ErrorResponse> invalidFormatException(UnsupportedFileTypeException exception) {
        ErrorResponse error = new ErrorResponse(STATUS, exception.getMessage());
        LOGGER.error(exception.getMessage());
        return new ResponseEntity<>(error, HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleException(Exception ex) {
        LOGGER.error("Unexpected error occurred: {}", ex.getMessage(), ex);
        ErrorResponse error = new ErrorResponse(STATUS, ex.getMessage());
        LOGGER.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

