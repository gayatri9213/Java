package com.csvtojson.sevice;

import com.csvtojson.util.UnsupportedFileTypeException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface CsvToJsonService {

    public ResponseEntity<Object> convertCsvToJsonFileFromUrl(String url, char delimiter, String jsonFileLocation) throws IOException, UnsupportedFileTypeException;

    public ResponseEntity<Object> convertCsvToJsonFileFromSystem(MultipartFile file, char delimiter, String jsonFileLocation) throws IOException, UnsupportedFileTypeException;

    public ResponseEntity<Object> convertCsvToJsonFileFromSharePoint(String fileName, char delimiter) throws IOException, UnsupportedFileTypeException;
}
