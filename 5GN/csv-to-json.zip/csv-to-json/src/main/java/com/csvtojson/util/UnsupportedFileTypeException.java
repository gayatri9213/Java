package com.csvtojson.util;

public class UnsupportedFileTypeException extends Exception {

    public UnsupportedFileTypeException(String message) {
        super(message);
    }
}
