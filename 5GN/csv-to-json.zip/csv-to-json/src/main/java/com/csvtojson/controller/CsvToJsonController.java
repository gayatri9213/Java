package com.csvtojson.controller;

import com.csvtojson.sevice.CsvToJsonServiceImpl;
import com.csvtojson.util.UnsupportedFileTypeException;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/csv-to-json")
@OpenAPIDefinition(info = @Info(title = "CSV to JSON Conversion APIs", version = "v1"))
public class CsvToJsonController {

    @Autowired
    private CsvToJsonServiceImpl csvToJsonServiceImpl;

    @PostMapping(value = "/url")
    @Operation(summary = "Convert CSV to JSON using Remote Location URL.")
    public ResponseEntity<Object> convertCsvToJsonFileFromUrl(@RequestParam String url, @RequestParam char delimiter, @RequestParam(value = "jsonFileLocation", required = false) String jsonFileLocation) throws IOException, UnsupportedFileTypeException {
        return csvToJsonServiceImpl.convertCsvToJsonFileFromUrl(url, delimiter, jsonFileLocation);
    }

    @PostMapping(value = "/file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Convert CSV to JSON using file upload")
    public ResponseEntity<Object> convertCsvToJsonFileFromSystem(@RequestParam(value = "file") MultipartFile file, @RequestParam char delimiter, @RequestParam(value = "jsonFileLocation", required = false) String jsonFileLocation) throws IOException, UnsupportedFileTypeException {
        return csvToJsonServiceImpl.convertCsvToJsonFileFromSystem(file, delimiter, jsonFileLocation);
    }

    @PostMapping(value = "/sharepoint/file")
    @Operation(summary = "Convert CSV to JSON using SharePoint file.")
    public ResponseEntity<Object> convertCsvToJsonFileFromSharePoint(@RequestParam(value = "fileName") String fileName, @RequestParam char delimiter) throws IOException, UnsupportedFileTypeException {
        return csvToJsonServiceImpl.convertCsvToJsonFileFromSharePoint(fileName, delimiter);
    }

    @PostMapping(value = "/sharepoint/fileLocation")
    @Operation(summary = "Convert CSV to JSON using SharePoint file location.")
    public ResponseEntity<Object> convertCsvToJsonFromSharePointUsingLocation(@RequestParam(value = "fileLocation") String fileUrl, @RequestParam char delimiter) throws IOException, UnsupportedFileTypeException {
        return csvToJsonServiceImpl.convertCsvToJsonFromSharePointUsingLocation(fileUrl, delimiter);
    }
}
