package com.csvtojson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvtojsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
