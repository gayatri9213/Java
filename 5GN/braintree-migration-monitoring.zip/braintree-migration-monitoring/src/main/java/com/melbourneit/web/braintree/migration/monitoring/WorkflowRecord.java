package com.melbourneit.web.braintree.migration.monitoring;

public class WorkflowRecord {

    private int id;
    private String transactionId;
    private int virtualisationId;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public int getVirtualisationId() {
        return virtualisationId;
    }
    public void setVirtualisationId(int virtualisationId) {
        this.virtualisationId = virtualisationId;
    }

    @Override
    public String toString() {
        return "WorkflowRecord [id=" + id + ", transactionId=" + transactionId + ", virtualisationId="
                + virtualisationId + "]";
    }

}
