package com.melbourneit.web.braintree.migration.monitoring;

public class CardRecord {

    private String greencode;
    private String btCustomerId;
    private int billingAccountId;

    public String getGreencode() {
        return greencode;
    }
    public void setGreencode(String greencode) {
        this.greencode = greencode;
    }
    public String getBtCustomerId() {
        return btCustomerId;
    }
    public void setBtCustomerId(String btCustomerId) {
        this.btCustomerId = btCustomerId;
    }
    public int getBillingAccountId() {
        return billingAccountId;
    }
    public void setBillingAccountId(int billingAccountId) {
        this.billingAccountId = billingAccountId;
    }

    @Override
    public String toString() {
        return "CardRecord [greencode=" + greencode + ", btCustomerId=" + btCustomerId + ", billingAccountId="
                + billingAccountId + "]";
    }

}
