package com.melbourneit.web.braintree.migration.monitoring;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.postgresql.ds.PGSimpleDataSource;
import org.slf4j.Logger;

import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.awssdk.services.sns.model.PublishRequest;
import software.amazon.awssdk.services.ssm.SsmClient;
import software.amazon.awssdk.services.ssm.model.GetParameterRequest;

public class Handler {

    private static final String TOPIC_ARN = "arn:aws:sns:ap-southeast-2:896226930240:PGW";

    private static final Logger logger = software.amazon.awssdk.utils.Logger.loggerFor(Handler.class).logger();

    private PGSimpleDataSource source;
    private SnsClient snsClient;

    private String workflowsSql;
    private String invoicesSql;
    private String cardsSql;
    private String customersSql;
    private String resellersSql;

    private String retrieveDbConnection() {
        try(final SsmClient client = SsmClient.create()) {
            final GetParameterRequest request = GetParameterRequest.builder()
                    .name("pgw-migration-monitoring.db.connection")
                    .withDecryption(Boolean.TRUE)
                    .build();
            final String str = client.getParameter(request).parameter().value();
            if(logger.isInfoEnabled()) {
                logger.info("DB connection [{}].", str.substring(0, 50));
            }
            return str;
        }
    }

    private void init() throws IOException {
        if(source == null) {
            source = new PGSimpleDataSource();
            source.setUrl(retrieveDbConnection());
            
            workflowsSql = IOUtils.toString(Handler.class.getResource("/workflows.sql"), StandardCharsets.UTF_8);
            invoicesSql = IOUtils.toString(Handler.class.getResource("/invoices.sql"), StandardCharsets.UTF_8);
            cardsSql = IOUtils.toString(Handler.class.getResource("/cards.sql"), StandardCharsets.UTF_8);
            customersSql = IOUtils.toString(Handler.class.getResource("/customers.sql"), StandardCharsets.UTF_8);
            resellersSql = IOUtils.toString(Handler.class.getResource("/resellers.sql"), StandardCharsets.UTF_8);

            snsClient = SnsClient.create();
        }
    }

    private WorkflowRecord readWorkflowRecord(final ResultSet rs) throws SQLException {
        final WorkflowRecord record = new WorkflowRecord();

        record.setId(rs.getInt("workflow_id"));
        record.setTransactionId(rs.getString("trans_id"));
        record.setVirtualisationId(rs.getInt("virtualisation_id"));

        return record;
    }

    private List<WorkflowRecord> checkWorkflows(final Connection connection) throws SQLException {
        try(final PreparedStatement stmt = connection.prepareStatement(workflowsSql);
                final ResultSet rs = stmt.executeQuery()) {

            final List<WorkflowRecord> workflows = new ArrayList<>();
            while (rs.next()) {
                final WorkflowRecord record = readWorkflowRecord(rs);
                workflows.add(record);
                logger.info("{}", record);
            }
            logger.info("Broken workflows [{}].", workflows.size());

            return workflows;
        }
    }

    private InvoiceRecord readInvoiceRecord(final ResultSet rs) throws SQLException {
        final InvoiceRecord record = new InvoiceRecord();

        record.setPaymentid(rs.getInt("paymentid"));
        record.setGreencode(rs.getString("coid"));
        record.setTransactionId(rs.getString("txnreg"));
        record.setTransactionTime(rs.getTimestamp("transactiondate").toInstant());
        record.setVirtualisationId(rs.getInt("virtualisation_id"));

        return record;
    }

    private List<InvoiceRecord> checkInvoices(final Connection connection) throws SQLException {
        try(final PreparedStatement stmt = connection.prepareStatement(invoicesSql);
                final ResultSet rs = stmt.executeQuery()) {

            final List<InvoiceRecord> invoices = new ArrayList<>();
            while (rs.next()) {
                final InvoiceRecord record = readInvoiceRecord(rs);
                invoices.add(record);
                logger.info("{}", record);
            }
            logger.info("Broken invoices [{}].", invoices.size());

            return invoices;
        }
    }

    private void sendMessage(final List<WorkflowRecord> workflows, final List<InvoiceRecord> invoices,
            final List<CardRecord> cards, final List<String> customers, final List<String> resellers) {

        final List<String> msgs = new ArrayList<>();
        if(!workflows.isEmpty()) {
            msgs.add("Broken workflows [" + workflows + "].");
        }
        if(!invoices.isEmpty()) {
            msgs.add("Broken invoices [" + invoices + "].");
        }
        if(!cards.isEmpty()) {
            msgs.add("Broken cards [" + cards + "].");
        }
        if(!customers.isEmpty()) {
            msgs.add("Broken customers [" + customers + "].");
        }
        if(!resellers.isEmpty()) {
            msgs.add("Broken resellers [" + resellers + "].");
        }

        final PublishRequest request = PublishRequest.builder()
                .topicArn(TOPIC_ARN)
                .message(msgs.stream().collect(Collectors.joining(System.lineSeparator() + System.lineSeparator())))
                .subject("Braintree migration error")
                .build();
        snsClient.publish(request);
    }

    private CardRecord readCardRecord(final ResultSet rs) throws SQLException {
        final CardRecord record = new CardRecord();

        record.setGreencode(rs.getString("greencode"));
        record.setBtCustomerId(rs.getString("bt_customer_id"));
        record.setBillingAccountId(rs.getInt("billing_account_id"));

        return record;
    }

    private String readCustomerRecord(final ResultSet rs) throws SQLException {
        return rs.getString("greencode");
    }

    private List<CardRecord> checkCards(final Connection connection) throws SQLException {
        try(final PreparedStatement stmt = connection.prepareStatement(cardsSql);
                final ResultSet rs = stmt.executeQuery()) {

            final List<CardRecord> cards = new ArrayList<>();
            while (rs.next()) {
                final CardRecord record = readCardRecord(rs);
                cards.add(record);
                logger.info("{}", record);
            }
            logger.info("Broken cards [{}].", cards.size());

            return cards;
        }
    }

    private List<String> checkCustomers(final Connection connection) throws SQLException {
        try(final PreparedStatement stmt = connection.prepareStatement(customersSql);
                final ResultSet rs = stmt.executeQuery()) {

            final List<String> customers = new ArrayList<>();
            while (rs.next()) {
                final String record = readCustomerRecord(rs);
                customers.add(record);
                logger.info("{}", record);
            }
            logger.info("Broken customers [{}].", customers.size());

            return customers;
        }
    }

    private List<String> checkResellers(final Connection connection) throws SQLException {
        try(final PreparedStatement stmt = connection.prepareStatement(resellersSql);
                final ResultSet rs = stmt.executeQuery()) {

            final List<String> resellers = new ArrayList<>();
            while (rs.next()) {
                final String record = readCustomerRecord(rs);
                resellers.add(record);
                logger.info("{}", record);
            }
            logger.info("Broken resellers [{}].", resellers.size());

            return resellers;
        }
    }

    public void handle() throws IOException, SQLException {
        init();

        try(final Connection connection = source.getConnection()) {
            final List<WorkflowRecord> workflows = checkWorkflows(connection);
            final List<InvoiceRecord> invoices = checkInvoices(connection);
            final List<CardRecord> cards = checkCards(connection);
            final List<String> customers = checkCustomers(connection);
            final List<String> resellers = checkResellers(connection);

            if(!workflows.isEmpty() || !invoices.isEmpty() || !cards.isEmpty() || !customers.isEmpty() || !resellers.isEmpty()) {
                sendMessage(workflows, invoices, cards, customers, resellers);
            }
        }
    }

}
