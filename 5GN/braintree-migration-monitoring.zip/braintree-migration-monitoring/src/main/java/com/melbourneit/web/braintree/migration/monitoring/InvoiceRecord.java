package com.melbourneit.web.braintree.migration.monitoring;

import java.time.Instant;

public class InvoiceRecord {

    private int paymentid;
    private Instant transactionTime;
    private String greencode;
    private String transactionId;
    private int virtualisationId;

    public int getPaymentid() {
        return paymentid;
    }
    public void setPaymentid(int paymentid) {
        this.paymentid = paymentid;
    }
    public Instant getTransactionTime() {
        return transactionTime;
    }
    public void setTransactionTime(Instant transactionTime) {
        this.transactionTime = transactionTime;
    }
    public String getGreencode() {
        return greencode;
    }
    public void setGreencode(String greencode) {
        this.greencode = greencode;
    }
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public int getVirtualisationId() {
        return virtualisationId;
    }
    public void setVirtualisationId(int virtualisationId) {
        this.virtualisationId = virtualisationId;
    }

    @Override
    public String toString() {
        return "InvoiceRecord [paymentid=" + paymentid + ", transactionTime=" + transactionTime + ", greencode="
                + greencode + ", transactionId=" + transactionId + ", virtualisationId=" + virtualisationId + "]";
    }

}
