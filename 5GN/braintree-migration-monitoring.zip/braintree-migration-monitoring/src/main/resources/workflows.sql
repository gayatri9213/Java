SELECT w.workflow_id, op.string_value as trans_id, w.virtualisation_id
FROM workflow w
LEFT JOIN os_propertyentry2 op ON w.workflow_id::character varying(255) = op.global_key AND op.item_key = 'payment.preauth.preauth'
LEFT JOIN os_propertyentry2 op_pc ON w.workflow_id::character varying(255) = op_pc.global_key AND op_pc.item_key = 'payment.accounting.productCode'
LEFT JOIN company c ON w.account_id = c.company_id
WHERE w.workflow IN ('productSetup2', 'domainregistration2', 'renewal2')
AND op_pc.string_value NOT IN ('PAYMT-PP','PAYMT-DIRDEB')
AND LENGTH(op.string_value) != 8
AND c.braintree_migrated = true
AND w.completed IS NOT NULL
AND w.virtualisation_id IN (1,8,10,16,17,19)
AND w.created > NOW() - INTERVAL '1 DAY';