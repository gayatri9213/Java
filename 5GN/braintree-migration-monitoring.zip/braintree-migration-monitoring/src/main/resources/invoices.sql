SELECT p.paymentid, p.transactiondate, p.coid, p.txnreg, p.virtualisation_id
FROM nraccounts.tblpayments p
LEFT JOIN company c ON p.coid = c.greencode
WHERE c.braintree_migrated = true
AND LENGTH(p.txnreg) != 8
AND p.productcode NOT IN ('PAYMT-PP','PAYMT-DIRDEB')
AND p.transactiontype IN ('PAYMENT', 'PURCHASE', 'RENEWAL', 'renewal')
AND substring(p.productdescription for 13) != 'BPay Payment '
AND p.virtualisation_id IN (1,8,10,16,17,19)
AND p.transactiondate > NOW() - INTERVAL '1 DAY';