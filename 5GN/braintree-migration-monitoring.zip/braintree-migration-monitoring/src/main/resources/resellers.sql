SELECT c.greencode
FROM reseller r
LEFT JOIN company c ON c.company_id = r.company_id
LEFT JOIN (SELECT reseller_id, COUNT(*) AS count
FROM company
WHERE braintree_migrated = false
GROUP BY reseller_id
) ct ON ct.reseller_id = r.reseller_id
WHERE c.braintree_migrated = true
AND c.virtualisation_id NOT IN (1,16,17)
AND ct.count > 0;