SELECT greencode
FROM company
WHERE braintree_migrated = false
AND virtualisation_id IN (1,8,10,16,17,19);