SELECT c.greencode, c.bt_customer_id, cca.billing_account_id
FROM credit_card_account cca
LEFT JOIN billing_account ba ON ba.billing_account_id = cca.billing_account_id
LEFT JOIN company c ON c.company_id = ba.account_id
WHERE c.braintree_migrated = true
AND c.virtualisation_id IN (1,8,10,16,17,19);