package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netbox.fresh.integration.model.Asset;
import com.netbox.fresh.integration.model.Circuit;
import com.netbox.fresh.integration.model.Device;
import com.netbox.fresh.integration.model.Rack;
import com.netbox.fresh.integration.repository.AssetRepository;
import com.netbox.fresh.integration.util.ConstantsConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AssetServiceImpl implements AssetService {
    private final Logger logger = LoggerFactory.getLogger(AssetServiceImpl.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    @Autowired
    private DeviceServiceImpl deviceService;

    @Autowired
    private RackServiceImpl rackService;

    @Autowired
    private CircuitServiceImpl circuitService;

    @Autowired
    private AssetRepository assetRepository;

    @Override
    public ResponseEntity<String> getAssetDetails() throws JsonProcessingException {
        List<Rack> racks = rackService.getAllRacks();
        Set<Long> rackNetboxIds = assetRepository.findAll()
                .stream()
                .filter(asset -> asset.getType().equals("rack"))
                .map(Asset::getNetboxId)
                .collect(Collectors.toSet());

        Set<Long> deviceNetboxIds = assetRepository.findAll()
                .stream()
                .filter(asset -> asset.getType().equals("device"))
                .map(Asset::getNetboxId)
                .collect(Collectors.toSet());

        for (Rack rack : racks) {
            if (!rackNetboxIds.contains(rack.getId())) {
                Map<String, Object> rackTypeFields = new HashMap<>();
                rackTypeFields.put("role_" + ConstantsConfig.RACK_ASSET_TYPE_DC_RACK, rack.getRole().getName());
                rackTypeFields.put("status_" + ConstantsConfig.RACK_ASSET_TYPE_DC_RACK, rack.getStatus().getLabel());
                long rackAssetId = createAsset(rack.getName(), ConstantsConfig.RACK_ASSET_TYPE_DC_RACK, rackTypeFields);
                saveAsset(rackAssetId, rack.getId(), "rack");
                if (rack.getDeviceCount() == 0)
                    continue;
                List<Device> devices = deviceService.getDevicesByRackId(rack.getId());
                for (Device device : devices) {
                    if (rack.getId() == device.getRack().getId() && !deviceNetboxIds.contains(device.getId())) {
                        if("null"!=device.getName()){
                            Map<String, Object> deviceTypeFields = new HashMap<>();
                            deviceTypeFields.put("vendormodel_" + ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE, device.getDeviceType().getManufacturer().getName());
                            deviceTypeFields.put("model_" + ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE_MODEL, device.getDeviceType().getModel());
                            deviceTypeFields.put("role_" + ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE, device.getRole().getName());
                            long deviceAssetId = createAsset(device.getName(), ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE, deviceTypeFields);
                            saveAsset(deviceAssetId, device.getId(), "device");
                            createAssetRelationship(rackAssetId, deviceAssetId);
                        }
                    }
                }
            }
        }


        return ResponseEntity.status(HttpStatus.OK).body("Assets and Relationships are successfully created.");
    }

    /*@Override
    public ResponseEntity<String> getAssetDetails() throws JsonProcessingException {
        List<Rack> racks = rackService.getAllRacks();
        for (Rack rack : racks) {
            Optional<Asset> existingAsset = assetRepository.findByNetboxIdAndType(rack.getId(), "rack");
            if (existingAsset.isPresent()) {
                logger.info("{}{}", ConstantsConfig.FRESH_ASSET_EXISTS_RACK, rack.getId());
                continue;
            }
            Map<String, Object> rackTypeFields = new HashMap<>();
            rackTypeFields.put("role_" + ConstantsConfig.RACK_ASSET_TYPE_DC_RACK, rack.getRole().getName());
            rackTypeFields.put("status_" + ConstantsConfig.RACK_ASSET_TYPE_DC_RACK, rack.getStatus().getLabel());
            long rackAssetId = createAsset(rack.getName(), ConstantsConfig.RACK_ASSET_TYPE_DC_RACK, rackTypeFields);
            saveAsset(rackAssetId, rack.getId(), "rack");
            if (rack.getDeviceCount() == 0)
                continue;
            List<Device> devices = deviceService.getDevicesByRackId(rack.getId());
            for (Device device : devices) {
                existingAsset = assetRepository.findByNetboxIdAndType(device.getId(), "device");
                if (existingAsset.isPresent() || device.getName().equals("null")) {
                    logger.info("{} {}", ConstantsConfig.FRESH_ASSET_EXISTS_DEVICE, rack.getId());
                    continue;
                }
                Map<String, Object> deviceTypeFields = new HashMap<>();
                deviceTypeFields.put("vendormodel_" + ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE, device.getDeviceType().getManufacturer().getName());
                deviceTypeFields.put("model_" + ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE_MODEL, device.getDeviceType().getModel());
                deviceTypeFields.put("role_" + ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE, device.getRole().getName());
                long deviceAssetId = createAsset(device.getName(), ConstantsConfig.DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE, deviceTypeFields);
                saveAsset(deviceAssetId, device.getId(), "device");
                if (rack.getId() == device.getRack().getId()) {
                    createAssetRelationship(rackAssetId, deviceAssetId);
                }
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body("Assets and Relationships are successfully created.");
    }*/

    @Override
    public ResponseEntity<String> getCircuitAssetDetails() throws JsonProcessingException {
        List<Circuit> circuits = circuitService.getAllCircuits();

        Set<Long> circuitNetboxIds = assetRepository.findAll()
                .stream()
                .filter(asset -> asset.getType().equals("circuit"))
                .map(Asset::getNetboxId)
                .collect(Collectors.toSet());

        for (Circuit circuit : circuits) {
            if (!circuitNetboxIds.contains(circuit.getId())) {
                Map<String, Object> circuitTypeFields = new HashMap<>();
                long circuitAssetId = createAsset(circuit.getCircuitId(), getAssetTypeId(circuit.getType().getName()), circuitTypeFields);
                saveAsset(circuitAssetId, circuit.getId(), "circuit");
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body("Assets are successfully created for circuits.");
    }

    private long createAsset(String name, long assetTypeId, Map<String, Object> typeFields) throws JsonProcessingException {
        logger.info(ConstantsConfig.FRESH_ASSET_CREATE);
        Map<String, Object> requestBody = new HashMap<>();
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        headers.set("Authorization", "Basic " + Base64.getEncoder().encodeToString(env.getProperty("fresh.api.key").getBytes()));
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        requestBody.put("name", name);
        requestBody.put("asset_type_id", assetTypeId);
        requestBody.put("type_fields", typeFields);
        try {
            HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);
            ResponseEntity<String> rackAsset = restTemplate.exchange(
                    env.getProperty("fresh.instance.url") + env.getProperty("fresh.api.version") + "assets",
                    HttpMethod.POST, requestEntity, String.class);
            JsonNode rootNode = objectMapper.readTree(rackAsset.getBody());
            JsonNode assetsNode = rootNode.path(ConstantsConfig.ASSET);
            return assetsNode.get("display_id").asLong();
        }catch (HttpClientErrorException.BadRequest e){
            Map<String, Object> deviceTypeFields = new HashMap<>();
            requestBody.put("type_fields", deviceTypeFields);
            HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);
            ResponseEntity<String> rackAsset = restTemplate.exchange(
                    env.getProperty("fresh.instance.url") + env.getProperty("fresh.api.version") + "assets",
                    HttpMethod.POST, requestEntity, String.class);
            JsonNode rootNode = objectMapper.readTree(rackAsset.getBody());
            JsonNode assetsNode = rootNode.path(ConstantsConfig.ASSET);
            return assetsNode.get("display_id").asLong();
        }

    }

    private void createAssetRelationship(long rackAssetId, long deviceAssetId) throws JsonProcessingException {
        logger.info(ConstantsConfig.FRESH_RELATIONSHIP_CREATE);
        Map<String, Object> requestBody = new HashMap<>();
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        headers.set("Authorization", "Basic " + Base64.getEncoder().encodeToString(env.getProperty("fresh.api.key").getBytes()));
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        requestBody.put("relationship_type_id", ConstantsConfig.RELATIONSHIP_TYPE_ID);
        requestBody.put("primary_id", rackAssetId);
        requestBody.put("primary_type", ConstantsConfig.ASSET);
        requestBody.put("secondary_id", deviceAssetId);
        requestBody.put("secondary_type", ConstantsConfig.ASSET);
        String requestBodyJson = objectMapper.writeValueAsString(requestBody);
        String json = "{\n\"relationships\": \n[" + requestBodyJson + "] \n}";
        HttpEntity<String> requestEntity = new HttpEntity<>(json, headers);
        restTemplate.exchange(env.getProperty("fresh.instance.url") + env.getProperty("fresh.api.version") + "relationships/bulk-create",
                HttpMethod.POST,
                requestEntity,
                String.class);
        logger.info("Relationship Created between {} {} ...", rackAssetId, deviceAssetId);
    }

    private void saveAsset(long assetId, long netboxId, String type) {
        Asset asset = new Asset();
        asset.setAssetId(assetId);
        asset.setNetboxId(netboxId);
        asset.setType(type);
        assetRepository.save(asset);
    }

    private long getAssetTypeId(String assetType) {
        switch (assetType) {
            case "CloudPort":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_CLOUDPORT;
            case "Crossconnect":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_CROSSCONNECT;
            case "Dark Fibre":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_DARKFIBRE;
            case "ENNI":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_ENNI;
            case "Equinix Connect":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_EQUINIXCONNECT;
            case "Ethernet Backhaul":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_ETHERNETBACKHAUL;
            case "Multi-services Trunk":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_MULTISERVICESTRUNK;
            case "Out-of-Band":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_OUTOFBRAND;
            case "Peering":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_PEERING;
            case "TPG Trunk":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_TPGTRUNK;
            case "Transit":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_TRANSIT;
            case "Wavelength":
                return ConstantsConfig.CIRCUIT_ASSET_TYPE_WAVELENGTH;
            default:
                return 0;
        }
    }

}
