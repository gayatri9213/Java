package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.netbox.fresh.integration.model.Circuit;

import java.util.List;

public interface CircuitService {
    public List<Circuit> getAllCircuits() throws JsonProcessingException;
}
