package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netbox.fresh.integration.model.Circuit;
import com.netbox.fresh.integration.model.Type;
import com.netbox.fresh.integration.util.ConstantsConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class CircuitServiceImpl implements CircuitService {

    private final Logger logger = LoggerFactory.getLogger(CircuitServiceImpl.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    @Override
    public List<Circuit> getAllCircuits() throws JsonProcessingException {
        List<Circuit> circuits = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Authorization", "Token " + env.getProperty("netBox.token"));
        HttpEntity<Object> entity = new HttpEntity<>(headers);
        String apiUrl = env.getProperty("netBox.instance.url") + ConstantsConfig.CIRCUIT_URL;
        String paginationUrl = apiUrl + "?limit=30&offset=0";
        boolean hasMoreData = true;
        int offset = 0;
        while (hasMoreData) {
            ResponseEntity<String> response = restTemplate.exchange(
                    paginationUrl,
                    HttpMethod.GET,
                    entity,
                    String.class
            );
            JsonNode rootNode = objectMapper.readTree(response.getBody());
            JsonNode circuitsNode = rootNode.path("results");
            for (JsonNode circuitNode : circuitsNode) {
                Type type = null;
                JsonNode typeNode = circuitNode.path("type");
                if (null != typeNode && !typeNode.isNull()) {
                    type = new Type();
                    type.setId(typeNode.get("id").asLong());
                    type.setUrl(typeNode.get("url").asText());
                    type.setDisplay(typeNode.get("display").asText());
                    type.setName(typeNode.get("name").asText());
                    type.setSlug(typeNode.get("slug").asText());
                }
                Circuit circuit = new Circuit();
                circuit.setId(circuitNode.get("id").asLong());
                circuit.setCircuitId(circuitNode.get("cid").asText());
                circuit.setType(type);
                circuits.add(circuit);
            }
            int totalCount = rootNode.path("count").asInt();
            offset += circuitsNode.size();
            if (offset >= totalCount) {
                hasMoreData = false;
            } else {
                paginationUrl = apiUrl + "?limit=50&offset=" + offset;
            }
        }
        logger.info("circuits size: {}", circuits.size());
        return circuits;
    }
}
