package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netbox.fresh.integration.model.Rack;
import com.netbox.fresh.integration.model.Role;
import com.netbox.fresh.integration.model.Status;
import com.netbox.fresh.integration.util.ConstantsConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class RackServiceImpl implements RackService {

    private final Logger logger = LoggerFactory.getLogger(RackServiceImpl.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    @Override
    public List<Rack> getAllRacks() throws JsonProcessingException {
        List<Rack> racks = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Authorization", "Token " + env.getProperty("netBox.token"));
        HttpEntity<Object> entity = new HttpEntity<>(headers);
        String apiUrl = env.getProperty("netBox.instance.url") + ConstantsConfig.RACK_URL;
        String paginationUrl = apiUrl + "?limit=50&offset=0";
        boolean hasMoreData = true;
        int offset = 0;
        while (hasMoreData) {
            ResponseEntity<String> response = restTemplate.exchange(
                    paginationUrl,
                    HttpMethod.GET,
                    entity,
                    String.class
            );
            JsonNode rootNode = objectMapper.readTree(response.getBody());
            JsonNode racksNode = rootNode.path("results");
            for (JsonNode rackNode : racksNode) {
                Status status = null;
                JsonNode statusNode = rackNode.path("status");
                if (null != statusNode && !statusNode.isNull()) {
                    status = new Status();
                    status.setValue(statusNode.get("value").asText());
                    status.setLabel(statusNode.get("label").asText());
                }
                Role role = null;
                JsonNode roleNode = rackNode.path("role");
                if (null != roleNode && !roleNode.isNull()) {
                    role = new Role();
                    role.setId(roleNode.get("id").asLong());
                    role.setUrl(roleNode.get("url").asText());
                    role.setDisplay(roleNode.get("display").asText());
                    role.setName(roleNode.get("name").asText());
                    role.setSlug(roleNode.get("slug").asText());
                }
                Rack rack = new Rack();
                rack.setId(rackNode.get("id").asLong());
                rack.setUrl(rackNode.get("url").asText());
                rack.setDisplay(rackNode.get("display").asText());
                rack.setName(rackNode.get("name").asText());
                rack.setStatus(status);
                rack.setRole(role);
                rack.setDeviceCount(rackNode.get("device_count").asLong());
                racks.add(rack);
            }
            int totalCount = rootNode.path("count").asInt();
            offset += racksNode.size();
            if (offset >= totalCount) {
                hasMoreData = false;
            } else {
                paginationUrl = apiUrl + "?limit=50&offset=" + offset;
            }
        }
        logger.info("Fetched rack size: {}", racks.size());
        return racks;
    }
}
