package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netbox.fresh.integration.model.*;
import com.netbox.fresh.integration.util.ConstantsConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class DeviceServiceImpl implements DeviceService {

    private final Logger logger = LoggerFactory.getLogger(DeviceServiceImpl.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    @Override
    public List<Device> getDevicesByRackId(long rackId) throws JsonProcessingException {
        List<Device> devices = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Authorization", "Token " + env.getProperty("netBox.token"));
        HttpEntity<Object> entity = new HttpEntity<>(headers);
        String apiUrl = env.getProperty("netBox.instance.url") + ConstantsConfig.DEVICE_URL + "?rack_id=" + rackId;
        String paginationUrl = apiUrl + "&limit=50&offset=0";
        boolean hasMoreData = true;
        int offset = 0;
        while (hasMoreData) {
            ResponseEntity<String> response = restTemplate.exchange(
                    paginationUrl,
                    HttpMethod.GET,
                    entity,
                    String.class
            );
            JsonNode rootNode = objectMapper.readTree(response.getBody());
            JsonNode devicesNode = rootNode.path("results");
            for (JsonNode deviceNode : devicesNode) {
                DeviceType deviceType = null;
                JsonNode deviceTypeNode = deviceNode.path("device_type");
                if (null != deviceTypeNode && !deviceTypeNode.isNull()) {
                    deviceType = new DeviceType();
                    deviceType.setId(deviceNode.get("id").asLong());
                    deviceType.setUrl(deviceNode.get("url").asText());
                    Manufacturer manufacturer = null;
                    JsonNode manufacturerNode = deviceNode.path("device_type").path("manufacturer");
                    if (null != manufacturerNode && !manufacturerNode.isNull()) {
                        manufacturer = new Manufacturer();
                        manufacturer.setId(manufacturerNode.get("id").asLong());
                        manufacturer.setUrl(manufacturerNode.get("url").asText());
                        manufacturer.setName(manufacturerNode.get("name").asText());
                        manufacturer.setSlug(manufacturerNode.get("slug").asText());
                    }
                    deviceType.setManufacturer(manufacturer);
                    deviceType.setModel(deviceTypeNode.get("model").asText());
                    deviceType.setSlug(deviceTypeNode.get("slug").asText());
                }

                Role deviceRole = null;
                JsonNode roleNode = deviceNode.path("device_role");
                if (null != roleNode && !roleNode.isNull()) {
                    deviceRole = new Role();
                    deviceRole.setId(roleNode.get("id").asLong());
                    deviceRole.setName(roleNode.get("name").asText());
                    deviceRole.setUrl(roleNode.get("url").asText());
                    deviceRole.setSlug(roleNode.get("slug").asText());
                }

                Rack rack = null;
                JsonNode rackNode = deviceNode.path("rack");
                if (null != rackNode && !rackNode.isNull()) {
                    rack = new Rack();
                    rack.setId(rackNode.get("id").asLong());
                    rack.setUrl(rackNode.get("url").asText());
                    rack.setName(rackNode.get("name").asText());
                }
                Status status = null;
                JsonNode statusNode = deviceNode.path("status");
                if (null != statusNode && !statusNode.isNull()) {
                    status = new Status();
                    status.setValue(statusNode.get("value").asText());
                    status.setLabel(statusNode.get("label").asText());
                }
                Device device = new Device();
                device.setId(deviceNode.get("id").asLong());
                device.setName(deviceNode.get("name").asText());
                device.setDisplay(deviceNode.get("display").asText());
                device.setDeviceType(deviceType);
                device.setRole(deviceRole);
                device.setRack(rack);
                device.setStatus(status);
                devices.add(device);
            }
            int totalCount = rootNode.path("count").asInt();
            offset += devicesNode.size();
            if (offset >= totalCount) {
                hasMoreData = false;
            } else {
                paginationUrl = apiUrl + "?limit=50&offset=" + offset;
            }
        }
        logger.info("devices size: {}", devices.size());
        return devices;
    }
}