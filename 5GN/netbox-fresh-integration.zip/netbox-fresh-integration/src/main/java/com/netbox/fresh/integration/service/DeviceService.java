package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.netbox.fresh.integration.model.Device;

import java.util.List;

public interface DeviceService {
    public List<Device> getDevicesByRackId(long rackId) throws JsonProcessingException;
}
