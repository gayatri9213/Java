package com.netbox.fresh.integration.controller;

import com.netbox.fresh.integration.CreateAssetsScheduler;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/scheduler")
public class SchedulerController {

    @Autowired
    private ScheduledAnnotationBeanPostProcessor postProcessor;

    @Autowired
    private CreateAssetsScheduler createAssetsScheduler;


    @PostMapping(value = "/stop-create-assets")
    @Operation(summary = "This API is used to stop asset creation.")
    public String stopCreateAssetsScheduler() {
        postProcessor.postProcessBeforeDestruction(createAssetsScheduler, "createAssetsScheduler");
        return "OK";
    }

    @PostMapping(value = "/start-create-assets")
    @Operation(summary = "This API is used to start asset creation.")
    public String startCreateAssetsScheduler() {
        postProcessor.postProcessAfterInitialization(createAssetsScheduler, "createAssetsScheduler");
        return "OK";
    }
}
