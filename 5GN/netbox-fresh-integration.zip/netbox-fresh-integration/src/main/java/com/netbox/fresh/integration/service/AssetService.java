package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.http.ResponseEntity;

public interface AssetService {
    public ResponseEntity<String> getAssetDetails() throws JsonProcessingException;

    public ResponseEntity<String> getCircuitAssetDetails() throws JsonProcessingException ;
}
