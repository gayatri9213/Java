package com.netbox.fresh.integration;

import com.netbox.fresh.integration.service.AssetServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.IOException;
import java.time.LocalDateTime;

@Configuration
public class CreateAssetsScheduler {

    private static final Logger logger = LoggerFactory.getLogger(CreateAssetsScheduler.class);

    @Autowired
    AssetServiceImpl assetService;

    //Schedule a task to run at 12:00 PM (Afternoon) every day.
    @Scheduled(cron = "0 0 12 * * *")
    public void createAssets() throws IOException {
        logger.info("Asset creation starting at : {}", LocalDateTime.now());
        assetService.getAssetDetails();
        assetService.getCircuitAssetDetails();
        logger.info("Asset creation completed at : {}", LocalDateTime.now());
    }
}
