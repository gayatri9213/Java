package com.netbox.fresh.integration.util;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ConstantsConfig {

    public static final String ASSET = "asset";
    public static final long RELATIONSHIP_TYPE_ID = 76000090255L; //relationship type “In Rack” and “Contains”
    public static final long RACK_ASSET_TYPE_DC_RACK = 76000259448L; //DC Rack asset type id
    public static final long DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE = 76000259450L; //Whole network node asset type id
    public static final long DEVICE_ASSET_TYPE_WHOLE_NETWORK_NODE_MODEL = 76001219586L; //Whole network node (model) asset type id
    public static final long CIRCUIT_ASSET_TYPE_CLOUDPORT = 76000014247L; //cloud port asset type id
    public static final long CIRCUIT_ASSET_TYPE_CROSSCONNECT = 76000260498L; //cross connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_DARKFIBRE = 76000014197L; //dark fibre asset type id
    public static final long CIRCUIT_ASSET_TYPE_ENNI = 76000260499L; //ENNI asset type id
    public static final long CIRCUIT_ASSET_TYPE_EQUINIXCONNECT = 76000260500L; //equinix connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_ETHERNETBACKHAUL = 76000260501L; //ethernet backhaul connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_MULTISERVICESTRUNK = 76000260502L;//multi services trunk connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_OUTOFBRAND = 76000260503L;//out of band connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_PEERING = 76000260504L;//peering connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_TPGTRUNK = 76000260505L;//TPG trunk connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_TRANSIT = 76000260506L;//transit connect asset type id
    public static final long CIRCUIT_ASSET_TYPE_WAVELENGTH = 76000014194L;//wavelength connect asset type id
    public static final String FRESH_ASSET_CREATE = "Creating assets in fresh service ...";
    public static final String FRESH_ASSET_EXISTS_RACK = "Asset already exists for rack ID : ";
    public static final String FRESH_ASSET_EXISTS_DEVICE = "Asset already exists for device ID : ";
    public static final String FRESH_ASSET_EXISTS_CIRCUIT = "Asset already exists for circuit ID : ";
    public static final String FRESH_RELATIONSHIP_CREATE = "Creating relationship between two assets in fresh service ...";
    public static final String CIRCUIT_URL = "api/circuits/circuits";
    public static final String DEVICE_URL = "api/dcim/devices";
    public static final String RACK_URL = "api/dcim/racks";
}
