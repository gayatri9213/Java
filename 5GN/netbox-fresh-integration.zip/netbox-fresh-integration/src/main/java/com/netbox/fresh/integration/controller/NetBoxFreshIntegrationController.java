package com.netbox.fresh.integration.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.netbox.fresh.integration.service.AssetServiceImpl;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/netBox-fresh")
@OpenAPIDefinition(info = @Info(title = "One Way Sync between NetBox and FreshService.", version = "v1"))
public class NetBoxFreshIntegrationController {

    @Autowired
    private AssetServiceImpl assetService;

    @PostMapping(value = "/assets")
    @Operation(summary = "This API is used to create assets and relationship between them")
    public ResponseEntity<String> syncAsset() throws JsonProcessingException {
        return assetService.getAssetDetails();
    }

    @PostMapping(value = "/circuit-assets")
    @Operation(summary = "This API is used to create assets for circuits")
    public ResponseEntity<String> circuitAsset() throws JsonProcessingException {
        return assetService.getCircuitAssetDetails();
    }
}
