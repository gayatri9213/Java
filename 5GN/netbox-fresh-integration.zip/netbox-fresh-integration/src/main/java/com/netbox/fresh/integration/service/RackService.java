package com.netbox.fresh.integration.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.netbox.fresh.integration.model.Rack;

import java.util.List;

public interface RackService {
    public List<Rack> getAllRacks() throws JsonProcessingException;
}
