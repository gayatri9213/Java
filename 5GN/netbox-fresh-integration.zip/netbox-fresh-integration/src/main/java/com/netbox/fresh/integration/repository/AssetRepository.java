package com.netbox.fresh.integration.repository;

import com.netbox.fresh.integration.model.Asset;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.Set;

@Repository
public interface AssetRepository extends JpaRepository<Asset, Long> {
    Optional<Asset> findByNetboxIdAndType(long netBoxId, String type);




}

