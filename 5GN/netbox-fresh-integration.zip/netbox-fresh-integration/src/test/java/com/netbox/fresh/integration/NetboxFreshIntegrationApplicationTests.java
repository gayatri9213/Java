package com.netbox.fresh.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetboxFreshIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
