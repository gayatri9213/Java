/*
Create Assets table 
*/

CREATE TABLE `assets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fresh_asset_id` bigint DEFAULT NULL,
  `datto_device_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


/*
Create Products table 
*/
CREATE TABLE `products` (
  `product_id` bigint NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `product_fresh_id` bigint DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `UK_noedb9y08edtorxiuh59adj0r` (`product_fresh_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

