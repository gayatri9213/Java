package com.cmdb.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmdbFreshIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
