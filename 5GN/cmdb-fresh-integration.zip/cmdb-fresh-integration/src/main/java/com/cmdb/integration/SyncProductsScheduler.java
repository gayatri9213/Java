package com.cmdb.integration;

import com.cmdb.integration.service.ProductServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;

@Configuration
public class SyncProductsScheduler {
    private static final Logger logger = LoggerFactory.getLogger(SyncProductsScheduler.class);

    @Autowired
    ProductServiceImpl productService;

    //Schedule a task to run at 6:00 AM and 6:00 PM every day.
    @Scheduled(cron = "0 0 6,18 * * *")
    public void syncProducts() throws JsonProcessingException {
        logger.info("Product Synchronization starting at : {}", LocalDateTime.now());
        productService.syncProducts();
        logger.info("Product Synchronization completed at : {}", LocalDateTime.now());
    }
}