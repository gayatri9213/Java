package com.cmdb.integration.service;

import com.cmdb.integration.model.Product;
import com.cmdb.integration.repository.ProductRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class ProductServiceImpl implements ProductService {

    private static final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");

    public static final String CONTEXT_PRODUCT = "products";

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public void syncProducts() throws JsonProcessingException {
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();

        logger.info(env.getProperty("fresh.product.sync.start"));
        headers.set("Authorization", "Basic " + Base64.getEncoder().encodeToString(env.getProperty("fresh.api.key").getBytes()));
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<Object> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(
                env.getProperty("fresh.base.url") + env.getProperty("fresh.api.version") + CONTEXT_PRODUCT,
                HttpMethod.GET, entity, String.class);
        JsonNode rootNode = objectMapper.readTree(response.getBody());
        JsonNode productsNode = rootNode.path(CONTEXT_PRODUCT);
        for (JsonNode productNode : productsNode) {
            Product product = new Product();
            product.setId(productNode.get("id").asLong());
            product.setName(productNode.get("name").asText());
            product.setCreatedAt(LocalDateTime.parse(productNode.get("created_at").asText(), FORMATTER));
            product.setUpdatedAt(LocalDateTime.parse(productNode.get("updated_at").asText(), FORMATTER));
            productRepository.saveOrUpdate(product);
        }
        logger.info(env.getProperty("fresh.product.sync.done"));
    }

    @Override
    public long createProduct(String name, long assetTypeId) throws IOException {
        long productId;
        Map<String, Object> requestBody = new HashMap<>();
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        logger.info(env.getProperty("fresh.product.create"));
        headers.set("Authorization", "Basic " + Base64.getEncoder().encodeToString(env.getProperty("fresh.api.key").getBytes()));
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        requestBody.put("name", name);
        requestBody.put("asset_type_id", assetTypeId);
        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);
        Optional<Product> existingProduct = productRepository.findByName(name);
        if (existingProduct.isPresent()) {
            Product updatedProduct = existingProduct.get();
            updatedProduct.setName(name);
            productRepository.save(updatedProduct);
            productId = updatedProduct.getId();
            logger.info("{} {}", env.getProperty("fresh.product.exists"), productId);
        } else {
            ResponseEntity<String> productData = restTemplate.exchange(
                    env.getProperty("fresh.base.url") + env.getProperty("fresh.api.version") + CONTEXT_PRODUCT,
                    HttpMethod.POST, requestEntity, String.class);
            JsonNode rootNode = objectMapper.readTree(productData.getBody());
            JsonNode productsNode = rootNode.path("product");
            Product product = new Product();
            product.setId(productsNode.get("id").asLong());
            product.setName(productsNode.get("name").asText());
            product.setCreatedAt(LocalDateTime.parse(productsNode.get("created_at").asText(), FORMATTER));
            product.setUpdatedAt(LocalDateTime.parse(productsNode.get("updated_at").asText(), FORMATTER));
            productRepository.save(product);
            productId = product.getId();
            logger.debug("{} {}", env.getProperty("fresh.product.created"), productId);
        }
        return productId;
    }

}
