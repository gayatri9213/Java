package com.cmdb.integration.controller;

import com.cmdb.integration.CreateAssetsScheduler;
import com.cmdb.integration.SyncProductsScheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/scheduler")
public class SchedulerController {

    @Autowired
    private ScheduledAnnotationBeanPostProcessor postProcessor;

    @Autowired
    private SyncProductsScheduler syncProductsScheduler;

    @Autowired
    private CreateAssetsScheduler createAssetsScheduler;

    @GetMapping(value = "/stop-sync-products")
    public String stopSyncProductsScheduler() {
        postProcessor.postProcessBeforeDestruction(syncProductsScheduler, "syncProductsScheduler");
        return "OK";
    }

    @GetMapping(value = "/start-sync-products")
    public String startSyncProductsScheduler() {
        postProcessor.postProcessAfterInitialization(syncProductsScheduler, "syncProductsScheduler");
        return "OK";
    }

    @GetMapping(value = "/stop-create-assets")
    public String stopCreateAssetsScheduler() {
        postProcessor.postProcessBeforeDestruction(createAssetsScheduler, "createAssetsScheduler");
        return "OK";
    }

    @GetMapping(value = "/start-create-assets")
    public String startCreateAssetsScheduler() {
        postProcessor.postProcessAfterInitialization(createAssetsScheduler, "createAssetsScheduler");
        return "OK";
    }
}
