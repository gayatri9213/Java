package com.cmdb.integration.service;

import com.cmdb.integration.model.Company;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;

public interface CompanyService {

    public List<Company> getAllCompanies() throws JsonProcessingException;
}
