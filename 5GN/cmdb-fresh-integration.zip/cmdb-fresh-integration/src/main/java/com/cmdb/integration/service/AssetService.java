package com.cmdb.integration.service;

import java.io.IOException;

public interface AssetService {

    public void createAsset() throws IOException;
}
