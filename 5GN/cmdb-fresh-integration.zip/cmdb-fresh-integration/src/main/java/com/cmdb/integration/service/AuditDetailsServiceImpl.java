package com.cmdb.integration.service;

import com.cmdb.integration.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
public class AuditDetailsServiceImpl implements AuditDetailsService {

    private final Logger logger = LoggerFactory.getLogger(AuditDetailsServiceImpl.class);

    private static final String SYSTEM_INFO="systemInfo";

    private static final String PHYSICAL_MEMORY="physicalMemory";

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    @Autowired
    private Token accessToken;

    @Override
    public Audit getAuditDetailsByDeviceId(String deviceId) throws JsonProcessingException {
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        logger.info("{} {}", env.getProperty("datto.audit.details"), deviceId);
        headers.set("Authorization", "Bearer " + accessToken.generateAccessToken());
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<Object> entity = new HttpEntity<>(headers);
        try {
            ResponseEntity<String> response = restTemplate.exchange(
                    env.getProperty("datto.endpoint") + env.getProperty("datto.api.version") + "audit/device/" + deviceId + "",
                    HttpMethod.GET, entity, String.class);
            JsonNode rootNode = objectMapper.readTree(response.getBody());
            SystemInfo systemInfo = new SystemInfo();
            if (rootNode.get(SYSTEM_INFO) != null) {
                systemInfo.setModel(rootNode.get(SYSTEM_INFO).get("model")!=null?rootNode.get(SYSTEM_INFO).get("model").asText():null);
                systemInfo.setTotalCpuCores(rootNode.get(SYSTEM_INFO).get("totalCpuCores").asLong());
            }
            PhysicalMemory physicalMemory = new PhysicalMemory();
            if (rootNode.get(PHYSICAL_MEMORY) != null && rootNode.get(PHYSICAL_MEMORY).isArray() && rootNode.get(PHYSICAL_MEMORY).size() > 0) {
                physicalMemory.setSize(rootNode.get(PHYSICAL_MEMORY).get(0).get("size").asLong());
            }
            Bios bios = new Bios();
            if (rootNode.get("bios") != null && rootNode.get("bios").get("serialNumber") != null) {
                bios.setSerialNumber(rootNode.get("bios").get("serialNumber").asText());
            }
            Audit audit = new Audit();
            audit.setSystemInfo(systemInfo);
            audit.setPhysicalMemory(physicalMemory);
            audit.setBios(bios);
            if (audit.getBios().getSerialNumber() == null ||
                    audit.getPhysicalMemory().getSize() == 0 ||
                    audit.getSystemInfo().getModel() == null ||
                    audit.getSystemInfo().getTotalCpuCores() == 0) {
                logger.warn("{} {} due to null audit details:",env.getProperty("datto.audit.details.skip"),deviceId);
                return null;
            }
            return audit;
        } catch (HttpClientErrorException e) {
            logger.warn("{} {} due to error :{}", env.getProperty("datto.audit.details.skip"), deviceId, e.getMessage());
            return null;
        }
    }
}