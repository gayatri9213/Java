package com.cmdb.integration.service;

import com.cmdb.integration.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
public class CompanyServiceImpl implements CompanyService {
    private static final Logger logger = LoggerFactory.getLogger(CompanyServiceImpl.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    public List<Company> getAllCompanies() throws JsonProcessingException {
        List<Company> companies = new ArrayList<>();
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        logger.info(env.getProperty("datto.company"));
        headers.set("Authorization", "Basic " + Base64.getEncoder().encodeToString(env.getProperty("fresh.api.key").getBytes()));
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<Object> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(
                env.getProperty("fresh.base.url") + env.getProperty("fresh.api.version") + "departments",
                HttpMethod.GET, entity, String.class);
        JsonNode rootNode = objectMapper.readTree(response.getBody());
        JsonNode companiesNode = rootNode.path("departments");
        for (JsonNode companyNode : companiesNode) {
            String siteId = companyNode.get("custom_fields").get("site_id").asText();
            if (!siteId.equals("null")) {
                Company company = new Company();
                company.setSiteId(siteId);
                logger.info("{}", company.getSiteId());
                companies.add(company);
            }
        }
        logger.info("{} {} ", env.getProperty("datto.company.retrieved"), companies.size());
        return companies;
    }
}
