package com.fresh.chat.controller.advice;

import com.fresh.chat.util.ApiError;
import com.fresh.chat.util.UnauthorizedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.webjars.NotFoundException;

import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
public class FreshChatControllerAdvice {
    private static final Logger logger = LoggerFactory.getLogger(FreshChatControllerAdvice.class);

    @ExceptionHandler
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ApiError errorHandling(final UnauthorizedException exception) {
        logger.error("UNAUTHORIZED  : ", exception);
        List<Object> details = new ArrayList<>();
        details.add(exception.getLocalizedMessage());
        return new ApiError(HttpStatus.UNAUTHORIZED, details);
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ApiError errorHandling(final NotFoundException exception) {
        logger.error("BAD_REQUEST : ", exception);
        List<Object> details = new ArrayList<>();
        details.add(exception.getLocalizedMessage());
        return new ApiError(HttpStatus.BAD_REQUEST, details);
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ApiError errorHandling(final Exception exception) {
        logger.error("INTERNAL_SERVER_ERROR : ", exception);
        List<Object> details = new ArrayList<>();
        details.add(exception.getLocalizedMessage());
        return new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, details);
    }
}