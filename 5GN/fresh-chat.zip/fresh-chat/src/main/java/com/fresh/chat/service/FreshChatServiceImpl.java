package com.fresh.chat.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fresh.chat.model.Lead;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class FreshChatServiceImpl implements FreshChatService {
    private static final Logger logger = LoggerFactory.getLogger(FreshChatServiceImpl.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Environment env;

    @Override
    public Map<String, String> createLead(Lead lead) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> leadData = new HashMap<>();
        headers.add("Content-Type", "application/json");
        headers.add("Authorization", "Bearer " + getAccessToken());
        leadData.put("FirstName", lead.getFirstName());
        leadData.put("LastName", lead.getLastName());
        leadData.put("Email", lead.getEmail());
        leadData.put("Phone", lead.getPhone());
        leadData.put("Company", lead.getCompany());
        String leadJson = new ObjectMapper().writeValueAsString(leadData);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity(leadJson, headers);
        String response = restTemplate.postForEntity(env.getProperty("salesForce.instance.url") + "services/data/v" + env.getProperty("salesForce.api.version") + "/sobjects/Lead/", request, String.class).getBody();
        logger.info("Lead Created Successfully . Response is : {}", response);
        Object json = objectMapper.readValue(response, Object.class);
        String responseJson = new ObjectMapper().writeValueAsString(json);
        JsonNode jsonNode = objectMapper.readTree(responseJson);
        String responseId = jsonNode.get("id").asText();
        String responseSuccess = jsonNode.get("success").asText();
        HashMap<String, String> map = new HashMap<>();
        map.put("Lead Id", responseId);
        map.put("Success", responseSuccess);
        return map;
    }

    private String getAccessToken() throws Exception {
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        HttpHeaders headers = new HttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        formData.add("username", env.getProperty("salesForce.username"));
        formData.add("password", env.getProperty("salesForce.password"));
        formData.add("grant_type", "password");
        formData.add("client_id", env.getProperty("salesForce.consumer.key"));
        formData.add("client_secret", env.getProperty("salesForce.consumer.secret"));
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
        String accessToken = restTemplate.postForObject(env.getProperty("salesForce.instance.url") + env.getProperty("salesForce.token.url"), request, String.class);
        Object json = objectMapper.readValue(accessToken, Object.class);
        String formattedAccessToken = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
        JsonNode jsonNode = objectMapper.readTree(formattedAccessToken);
        formattedAccessToken = jsonNode.get("access_token").asText();
        logger.info("Access token is generated");
        return formattedAccessToken;
    }
}
