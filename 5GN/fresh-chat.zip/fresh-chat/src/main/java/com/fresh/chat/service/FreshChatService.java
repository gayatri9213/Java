package com.fresh.chat.service;

import com.fresh.chat.model.Lead;
import java.util.Map;

public interface FreshChatService {
    public Map<String, String> createLead(Lead lead) throws Exception;
}
