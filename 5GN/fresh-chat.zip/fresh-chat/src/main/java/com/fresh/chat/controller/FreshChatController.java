package com.fresh.chat.controller;

import com.fresh.chat.model.Lead;
import com.fresh.chat.service.FreshChatServiceImpl;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping(value = "/salesForce")
@OpenAPIDefinition(info = @Info(title = "Salesforce integration using java", version = "v1"))
public class FreshChatController {

    @Autowired
    private FreshChatServiceImpl freshChatService;

    @ResponseBody
    @PostMapping(value = "/lead")
    @Operation(summary = "This API is used to create lead in salesforce")
    public Map<String, String> createLead(@Valid @RequestBody Lead lead) throws Exception {
        return freshChatService.createLead(lead);
    }

}
